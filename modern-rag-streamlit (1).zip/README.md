# Modern RAG Chatbot

## Setup

pip install -r requirements.txt

Install Ollama and run:

ollama pull llama3.2

## Start

streamlit run src/app.py

Upload a PDF and ask questions about it.